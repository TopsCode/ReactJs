import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const pStyle = {
  fontSize: '15px',
  textAlign: 'center',
  marginBottom:'10px'
};
class Input extends React.Component {
  constructor(props) {
    super(props);
    this.state = { value: "" };
    this.handleInput = this.handleInput.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  handleChange(event){
    // console.log(event.target.value);
    this.setState({ value: event.target.value });
  }
  handleInput(event){
    event.preventDefault();
    const input = this.state.value;
    if (input == "") {
      return;
    }
    this.setState({ value: "" });
    this.props.onChange(input);
  }
   render(){
    return(
      <form onSubmit={this.handleInput}>
        <input style={pStyle} value={this.state.value} type="text"  onChange={this.handleChange}></input>
      </form>
    )
  }
}
class ToDoList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {list: this.props.value };
    console.log(this.state);
  }
  render() {

    const displayList = this.state.list;
    let tagList = displayList.map((todos, i) => (
      <ToDo key={"item" + i} name={todos}/>
      ));
      console.log(tagList);
      return <ul>{tagList}</ul>;
    }
}
class ToDo extends React.Component {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }
  handleClick() {
    const todoName = this.props.name;
    this.props.onClick(todoName);
  }
  render() {
    return (
      <li>
        {this.props.name}
        
      </li>
      );
    }
  }
class ToDoApp extends React.Component {
  
  render() {
    return (
      <div className="todo-component">
        <h2>ToDo</h2>
        <div className="todo-box">
           <Input onChange={this.handleChange} />
           <ToDoList value={this.state.display} />
        </div>
      </div>
    );
  }
}

ReactDOM.render(<ToDoApp />, document.getElementById("root"));
