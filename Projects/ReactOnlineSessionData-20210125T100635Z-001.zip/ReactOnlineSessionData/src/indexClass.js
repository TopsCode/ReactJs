import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import * as serviceWorker from './serviceWorker';
class ParentClass extends React.Component{
    render(){
        return(<div>
            test
            {/* <ChildClass username="TOPS" Password="123"/> */}
            </div>);
    }
}
class ChildClass extends React.Component{
    render(){
        return(
            <div>
            <div>
                Test
            </div>
            <div>
                <h3>User Name is {this.props.username}</h3>
                <h3>Password is {this.props.Password}</h3>
                <h2>Technologies</h2>
            </div>
            </div>
            );
    }
}

ReactDOM.render(<ParentClass />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
