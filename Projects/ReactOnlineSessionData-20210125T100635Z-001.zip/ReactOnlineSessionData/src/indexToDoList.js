import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import 'bootstrap/dist/css/bootstrap.min.css';
// import './index.css';
    // import React, {Component} from 'react';
    // import ReactDOM from 'react-dom';
// class ErrorBoundary extends React.Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//        hasError : false,
//        error    : null,
//        info     : null
//     };
//   }

//   componentDidCatch(error, info) {
//     this.setState({ 
//       hasError : true, 
//       error    : error,
//       info     : info
//     });
//   }

//   render() {
//     if (this.state.hasError) {
//       return (
//         <div>
//           <h1>Oops!!! Something went wrong</h1>
//           <p><span>The error: </span> {this.state.error.toString()}</p>
//           <p><span>Where it occured:</span> {this.state.info.componentStack}</p>
//          </div> 
//           );
//     } else {
//       return this.props.children;
//     }
//   }
// }

class Input extends React.Component {
  constructor(props) {
    super(props);
    this.state = { value: "" };
    this.handleInput = this.handleInput.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(event) {
    this.setState({ value: event.target.value });
  }

  handleInput(event) {
    event.preventDefault();
    const input = this.state.value;
    if (input == "") {
      return;
    }
    this.setState({ value: "" });
    this.props.onChange(input);
  }

  render() {
    return (
      <form onSubmit={this.handleInput}>
        <input
          value={this.state.value}
          onChange={this.handleChange}
          placeholder="Add an Item"
        />
      </form>
    );
  }
}

class ToDo extends React.Component {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }
  //handles when the cancel button is clicked
  handleClick() {
    const todoName = this.props.name;
    this.props.onClick(todoName);
  }

  render() {
    return (
      <li>
        {this.props.name}
        <button onClick={this.handleClick}>X</button>
      </li>
    );
  }
}

class ToDoList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {list: this.props.value };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(todo) {
    let list = this.state.list;
    for (let i = 0; i < list.length; i++) {
      if (list[i] == todo) {
        list.splice(i, 1);
      }
    }
    const newList = list;
    this.setState({ list: newList });
  }

  render() {
    const displayList = this.state.list;
    let tagList = displayList.map((todos, i) => (
      <ToDo key={"item" + i} name={todos} onClick={this.handleClick} />
    ));
    return <ul>{tagList}</ul>;
  }
}

class ToDoApp extends React.Component {
  constructor(props) {
    super(props);
    this.state = { display: [], error: "" };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(newInput) {
    const isTag = (array, tag) => {
      for (let a = 0; a < array.length; a++) {
        if (array[a] == tag) {
          return true;
        }
      }
    };

    const todoArray = this.state.display;
    if (!isTag(todoArray, newInput)) {
      todoArray.push(newInput);
      this.setState({
        display: todoArray,
        error: ""
      });
    } else {
      this.setState({ error: "You've already added that item" });
    }
  }

  render() {
    return (
      <div className="todo-component">
        <h2>ToDo</h2>
        <div className="todo-box">
            <Input onChange={this.handleChange} />
          {/* <ErrorBoundary>
            <ToDoList value={this.state.display} />
          </ErrorBoundary> */}
        </div>
      </div>
    );
  }
}

ReactDOM.render(<ToDoApp />, document.getElementById("root"));
