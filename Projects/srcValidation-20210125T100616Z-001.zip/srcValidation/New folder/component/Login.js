import React from 'react';
import  App  from "../component/App";
import {
   
   FormGroup,
   FormControl
 } from "react-bootstrap";
class Login extends React.Component {
   render() {
      return (
         <div>
            <App/>
         	<h1>Login</h1>
            <form onSubmit={this.handleConfirmationSubmit}>
        <FormGroup controlId="confirmationCode" bsSize="large">
          <FormControl
            autoFocus
            type="tel"
            value="a"
          />
          
          </FormGroup>

          <div class="row">
  <div class="col-md-2"></div>
         <div class="col-md-6">
         <div class="card text-center">
  <div class="card-header">
    Featured
  </div>
  
  <div class="card-body">
         <div class="row form-group">
            <div class="col-md-3">
               <label>User Name</label>
            </div>
            <div class="col-md-9">
                 <input type="text" name="UserName" class="form-control"></input>
            </div>
         </div>
         <div class="row form-group">
            <div class="col-md-3">
               <label>Password</label>
            </div>
            <div class="col-md-9">
                 <input type="text" class="form-control"></input>
                  
            </div>
         </div>
         <div class="row form-group">
            <div class="col-md-3">
               
            </div>
            <div class="col-md-9">
                  <button class="btn btn-primary" bsStyle="primary" bsSize="xsmall"> test </button>
                  <button>Default</button>
            </div>
         </div>
   </div>
   <div class="card-footer text-muted">
      2 days ago
   </div>
   </div>
         </div>
  </div>



          
      </form>
         </div>
      )
   }
}
export default Login;
